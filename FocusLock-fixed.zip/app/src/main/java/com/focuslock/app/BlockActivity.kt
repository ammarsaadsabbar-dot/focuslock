package com.focuslock.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.Locale

class BlockActivity : ComponentActivity() {
    companion object {
        const val EXTRA_BLOCKED_PACKAGE = "blocked_package"

        @Volatile
        var isVisible: Boolean = false
            private set
    }

    private var blockedLabel by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        blockedLabel = resolveLabel(intent)
        setContent {
            FocusTheme {
                BackHandler { goHome() }
                var remaining by remember { mutableLongStateOf(LockStore.remainingMillis(this@BlockActivity)) }
                LaunchedEffect(Unit) {
                    while (true) {
                        remaining = LockStore.remainingMillis(this@BlockActivity)
                        if (remaining <= 0L) {
                            goHome()
                            break
                        }
                        delay(1000)
                    }
                }
                BlockScreen(blockedLabel, remaining) { goHome() }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        blockedLabel = resolveLabel(intent)
    }

    override fun onResume() {
        super.onResume()
        isVisible = true
    }

    override fun onPause() {
        isVisible = false
        super.onPause()
    }

    private fun resolveLabel(intent: Intent?): String? {
        val pkg = intent?.getStringExtra(EXTRA_BLOCKED_PACKAGE) ?: return null
        return runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        }.getOrNull()
    }

    private fun goHome() {
        val home = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(home) }
        finish()
    }
}

@Composable
private fun BlockScreen(appName: String?, remainingMs: Long, onGoHome: () -> Unit) {
    val totalSeconds = (remainingMs / 1000L).coerceAtLeast(0L)
    val time = String.format(
        Locale.US, "%02d:%02d:%02d",
        totalSeconds / 3600, (totalSeconds % 3600) / 60, totalSeconds % 60
    )
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.fillMaxSize().safeDrawingPadding().padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("وقت التركيز", style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(16.dp))
            Text(
                if (appName != null) "«$appName» محظور خلال جلسة التركيز." else "هذا التطبيق محظور خلال جلسة التركيز.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))
            Text(time, style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(28.dp))
            Button(onClick = onGoHome) { Text("العودة إلى الشاشة الرئيسية") }
            Spacer(Modifier.height(12.dp))
            Text(
                "لا يمكن إلغاء الجلسة. ينتهي الحظر عند انتهاء المؤقت.",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center
            )
        }
    }
}
