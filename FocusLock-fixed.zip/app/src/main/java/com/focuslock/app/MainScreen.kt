package com.focuslock.app

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale

@Composable
fun MainScreen(refreshKey: Int) {
    val context = LocalContext.current
    val appsState by produceState<List<LaunchableApp>?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { loadLaunchableApps(context) }
    }

    var selected by remember { mutableStateOf(LockStore.selectedPackages(context)) }
    var minutesText by rememberSaveable { mutableStateOf("60") }
    var remaining by remember { mutableLongStateOf(LockStore.remainingMillis(context)) }
    var serviceOn by remember { mutableStateOf(isServiceEnabled(context)) }
    var showHelp by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(refreshKey) {
        serviceOn = isServiceEnabled(context)
        remaining = LockStore.remainingMillis(context)
    }
    LaunchedEffect(Unit) {
        while (true) {
            remaining = LockStore.remainingMillis(context)
            serviceOn = isServiceEnabled(context)
            delay(1000)
        }
    }

    val active = remaining > 0L
    val minutes = minutesText.toLongOrNull() ?: 0L
    val apps = appsState
    // Apps that were uninstalled since last time are ignored.
    val validSelected = if (apps == null) selected else selected.filter { pkg -> apps.any { it.packageName == pkg } }.toSet()
    val canStart = serviceOn && validSelected.isNotEmpty() && minutes in 1L..LockStore.MAX_MINUTES

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(modifier = Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(8.dp))
            Text("Focus Lock", style = MaterialTheme.typography.headlineLarge)
            Text("قفل التطبيقات أثناء جلسة التركيز", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (active) {
                    item { ActiveCard(remaining) }
                } else {
                    if (!serviceOn || showHelp) item { SetupCard(context) }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("مدة القفل بالدقائق (حتى ${LockStore.MAX_MINUTES} دقيقة)")
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(25, 60, 90, 120, 240).forEach { m ->
                                    OutlinedButton(
                                        onClick = { minutesText = m.toString() },
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(0.dp)
                                    ) { Text("$m") }
                                }
                            }
                            TextField(
                                value = minutesText,
                                onValueChange = { v -> if (v.length <= 4 && v.all { it.isDigit() }) minutesText = v },
                                label = { Text("المدة بالدقائق") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text("اختر التطبيقات التي تريد حظرها:", style = MaterialTheme.typography.titleMedium)
                            Text("المحدد: ${validSelected.size}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (apps == null) {
                        item { CircularProgressIndicator() }
                    } else {
                        items(apps, key = { it.packageName }) { app ->
                            val checked = app.packageName in selected
                            Row(
                                modifier = Modifier.fillMaxWidth().toggleable(
                                    value = checked,
                                    role = Role.Checkbox,
                                    onValueChange = { on ->
                                        selected = if (on) selected + app.packageName else selected - app.packageName
                                        LockStore.saveSelectedPackages(context, selected)
                                    }
                                ).padding(vertical = 5.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(checked = checked, onCheckedChange = null)
                                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                                    Text(app.label, style = MaterialTheme.typography.bodyLarge)
                                    Text(app.packageName, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                    item {
                        TextButton(onClick = { showHelp = !showHelp }) {
                            Text(if (showHelp) "إخفاء مساعدة الإعداد" else "مساعدة الإعداد")
                        }
                    }
                }
                item {
                    Text(
                        "مهم: القفل يعتمد على خدمة إمكانية الوصول. إيقاف الخدمة أو فرض إيقاف التطبيق أو إلغاء تثبيته قد يتجاوز الحظر. تطبيقات الاتصال والطوارئ والشاشة الرئيسية لا يمكن حظرها.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            if (!active) {
                Spacer(Modifier.height(8.dp))
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = canStart,
                    onClick = { showConfirm = true }
                ) { Text(if (serviceOn) "بدء جلسة القفل" else "فعّل خدمة إمكانية الوصول أولاً") }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("تأكيد بدء الجلسة") },
            text = { Text("سيتم حظر ${validSelected.size} تطبيق لمدة $minutes دقيقة. لا يمكن إلغاء الجلسة بعد البدء.") },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    val toBlock = validSelected - Protected.packages(context)
                    if (toBlock.isNotEmpty()) {
                        LockStore.saveSelectedPackages(context, selected)
                        LockStore.startSession(context, minutes * 60_000L, toBlock)
                        remaining = LockStore.remainingMillis(context)
                    }
                }) { Text("ابدأ") }
            },
            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("تراجع") } }
        )
    }
}

@Composable
private fun ActiveCard(remainingMs: Long) {
    val s = remainingMs / 1000L
    val time = String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("جلسة قيد التشغيل", style = MaterialTheme.typography.titleLarge)
            Text("المتبقي: $time", style = MaterialTheme.typography.headlineMedium)
            Text("لا يمكن إلغاء الجلسة من داخل التطبيق.")
        }
    }
}

@Composable
private fun SetupCard(context: Context) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("تهيئة الجهاز (مرة واحدة)", style = MaterialTheme.typography.titleMedium)
            Text("1) افتح «معلومات التطبيق» ثم القائمة ⋮ في الأعلى واختر «السماح بالإعدادات المقيّدة». هذه الخطوة مطلوبة على أندرويد 13 فما فوق وإلا ستبقى خدمة إمكانية الوصول معطّلة.")
            OutlinedButton(onClick = { openAppDetails(context) }, modifier = Modifier.fillMaxWidth()) { Text("معلومات التطبيق") }
            Text("2) فعّل «Focus Lock — مراقبة التطبيقات» من إمكانية الوصول.")
            OutlinedButton(onClick = { openAccessibilitySettings(context) }, modifier = Modifier.fillMaxWidth()) { Text("إعدادات إمكانية الوصول") }
            Text("3) لشاومي/HyperOS: فعّل التشغيل التلقائي، وصلاحية «عرض نوافذ منبثقة أثناء التشغيل في الخلفية»، واجعل توفير الطاقة «بدون قيود».")
            OutlinedButton(onClick = { openAutostartSettings(context) }, modifier = Modifier.fillMaxWidth()) { Text("التشغيل التلقائي") }
            OutlinedButton(onClick = { openXiaomiPermissions(context) }, modifier = Modifier.fillMaxWidth()) { Text("صلاحيات التطبيق (HyperOS)") }
            OutlinedButton(onClick = { openBatterySettings(context) }, modifier = Modifier.fillMaxWidth()) { Text("إعدادات البطارية") }
        }
    }
}
