package com.focuslock.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.accessibility.AccessibilityManager

data class LaunchableApp(val label: String, val packageName: String)

/** Loads launchable apps. Slow on phones with many apps, so call it off the main thread. */
fun loadLaunchableApps(context: Context): List<LaunchableApp> {
    val pm = context.packageManager
    val blockedForever = Protected.packages(context)
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .mapNotNull { info ->
            val pkg = info.activityInfo.packageName
            if (pkg in blockedForever) null else LaunchableApp(info.loadLabel(pm).toString(), pkg)
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

fun isServiceEnabled(context: Context): Boolean {
    val manager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
        it.resolveInfo.serviceInfo.packageName == context.packageName &&
            it.resolveInfo.serviceInfo.name.endsWith("FocusAccessibilityService")
    }
}

private fun Context.launch(intent: Intent, fallback: Intent? = null) {
    try {
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        if (fallback != null) runCatching { startActivity(fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}

private fun Context.appDetailsIntent() =
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))

fun openAppDetails(context: Context) = context.launch(context.appDetailsIntent())

fun openAccessibilitySettings(context: Context) =
    context.launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

fun openBatterySettings(context: Context) =
    context.launch(
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
        context.appDetailsIntent()
    )

fun openAutostartSettings(context: Context) =
    context.launch(
        Intent().setComponent(
            ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
            )
        ),
        context.appDetailsIntent()
    )

fun openXiaomiPermissions(context: Context) =
    context.launch(
        Intent("miui.intent.action.APP_PERM_EDITOR")
            .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
            .putExtra("extra_pkgname", context.packageName),
        context.appDetailsIntent()
    )
