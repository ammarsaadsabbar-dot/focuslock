package com.focuslock.app

import android.content.Context
import android.os.SystemClock
import android.provider.Settings

/**
 * Session storage. The remaining time is kept as "remaining at an anchor" and advanced with the
 * monotonic clock (SystemClock.elapsedRealtime), so changing the date/time while the phone stays on
 * cannot shorten or extend a session. Across a reboot the wall clock is used as a fallback.
 */
object LockStore {
    private const val PREFS = "focus_lock_prefs"
    private const val KEY_SELECTED = "selected_packages"
    private const val KEY_SESSION_PACKAGES = "session_packages"
    private const val KEY_REMAINING = "anchor_remaining_ms"
    private const val KEY_ANCHOR_ELAPSED = "anchor_elapsed_ms"
    private const val KEY_ANCHOR_WALL = "anchor_wall_ms"
    private const val KEY_ANCHOR_BOOT = "anchor_boot_count"
    private const val CHECKPOINT_MS = 30_000L

    const val MAX_MINUTES = 1440L

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun bootCount(context: Context): Int = try {
        Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, -1)
    } catch (e: Exception) {
        -1
    }

    fun selectedPackages(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_SELECTED, emptySet())?.toSet() ?: emptySet()

    fun saveSelectedPackages(context: Context, packages: Set<String>) {
        prefs(context).edit().putStringSet(KEY_SELECTED, packages.toSet()).apply()
    }

    fun activePackages(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_SESSION_PACKAGES, emptySet())?.toSet() ?: emptySet()

    @Synchronized
    fun startSession(context: Context, durationMs: Long, packages: Set<String>) {
        prefs(context).edit()
            .putStringSet(KEY_SESSION_PACKAGES, packages.toSet())
            .putLong(KEY_REMAINING, durationMs)
            .putLong(KEY_ANCHOR_ELAPSED, SystemClock.elapsedRealtime())
            .putLong(KEY_ANCHOR_WALL, System.currentTimeMillis())
            .putInt(KEY_ANCHOR_BOOT, bootCount(context))
            .apply()
    }

    /** Remaining milliseconds of the active session, or 0 when there is none (expired sessions are cleared). */
    @Synchronized
    fun remainingMillis(context: Context, forceCheckpoint: Boolean = false): Long {
        val p = prefs(context)
        if (!p.contains(KEY_REMAINING)) return 0L

        val stored = p.getLong(KEY_REMAINING, 0L)
        val anchorElapsed = p.getLong(KEY_ANCHOR_ELAPSED, 0L)
        val anchorWall = p.getLong(KEY_ANCHOR_WALL, 0L)
        val anchorBoot = p.getInt(KEY_ANCHOR_BOOT, -1)

        val nowElapsed = SystemClock.elapsedRealtime()
        val nowWall = System.currentTimeMillis()
        val rebooted = bootCount(context) != anchorBoot || nowElapsed < anchorElapsed

        val consumed = TimeMath.consumed(rebooted, nowElapsed, anchorElapsed, nowWall, anchorWall)
        val remaining = (stored - consumed).coerceAtLeast(0L)

        if (remaining <= 0L) {
            clearSession(context)
            return 0L
        }
        if (rebooted || forceCheckpoint || consumed >= CHECKPOINT_MS) {
            p.edit()
                .putLong(KEY_REMAINING, remaining)
                .putLong(KEY_ANCHOR_ELAPSED, nowElapsed)
                .putLong(KEY_ANCHOR_WALL, nowWall)
                .putInt(KEY_ANCHOR_BOOT, bootCount(context))
                .apply()
        }
        return remaining
    }

    fun isSessionActive(context: Context): Boolean = remainingMillis(context) > 0L

    private fun clearSession(context: Context) {
        prefs(context).edit()
            .remove(KEY_REMAINING)
            .remove(KEY_ANCHOR_ELAPSED)
            .remove(KEY_ANCHOR_WALL)
            .remove(KEY_ANCHOR_BOOT)
            .remove(KEY_SESSION_PACKAGES)
            .apply()
    }
}
