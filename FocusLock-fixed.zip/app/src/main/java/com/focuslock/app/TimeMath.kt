package com.focuslock.app

/** Pure time arithmetic, kept free of Android types so it is easy to reason about and test. */
object TimeMath {
    /**
     * Milliseconds consumed since the anchor.
     * Same boot: the monotonic clock is used, so changing the phone's date has no effect.
     * After a reboot the monotonic clock restarts, so the wall clock is the only option.
     * A wall clock moved backwards never gives time back (clamped at zero).
     */
    fun consumed(
        rebooted: Boolean,
        nowElapsed: Long,
        anchorElapsed: Long,
        nowWall: Long,
        anchorWall: Long
    ): Long = if (rebooted) maxOf(0L, nowWall - anchorWall) else maxOf(0L, nowElapsed - anchorElapsed)
}
