package com.focuslock.app

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat

class FocusAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastLaunchAt = 0L
    private var receiverRegistered = false

    // When the user changes the clock, re-anchor the session so a later reboot cannot be abused.
    private val timeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            LockStore.remainingMillis(context.applicationContext, forceCheckpoint = true)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (!receiverRegistered) {
            ContextCompat.registerReceiver(
                this,
                timeReceiver,
                IntentFilter(Intent.ACTION_TIME_CHANGED),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg !in LockStore.activePackages(this)) return
        if (LockStore.remainingMillis(this) <= 0L) return
        if (BlockActivity.isVisible) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastLaunchAt < 300L) return
        lastLaunchAt = now
        block(pkg)
    }

    private fun block(pkg: String) {
        val intent = Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(BlockActivity.EXTRA_BLOCKED_PACKAGE, pkg)
        }
        runCatching { startActivity(intent) }
        // Some vendor ROMs (e.g. HyperOS) silently refuse background activity starts.
        // If the block screen did not appear, at least push the blocked app away.
        handler.postDelayed({
            if (!BlockActivity.isVisible) performGlobalAction(GLOBAL_ACTION_HOME)
        }, 800L)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (receiverRegistered) {
            runCatching { unregisterReceiver(timeReceiver) }
            receiverRegistered = false
        }
        super.onDestroy()
    }
}
